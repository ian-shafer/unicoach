﻿*** Created: 9/23/2025 8:08:32 PM                            
*
* Modify the path below to point to your data file.
* The specified subdirectory was not created on
* your computer. You will need to do this.
*
* The stat program must be run against the specified
* data file. This file is specified in the program
* and must be saved separately.
*
* This program does not provide tab or summarize for all
* variables.
*
* There may be missing data for some institutions due
* to the merge used to create this file.
*
* This program does not include reserved values in its
* calculations for missing values.
*
* You may need to adjust your memory settings depending
* upon the number of variables and records.
*
* The save command may need to be modified per user
* requirements.
*
* For long lists of value labels, the titles may be
* shortened per program requirements.
*

insheet using "e:\shares\ipeds\dct\IC2023_data_stata.csv", comma clear
label data "dct_IC2023"
label variable unitid       "Unique identification number of the institution"
label variable peo1istr     "Occupational"
label variable peo2istr     "Academic"
label variable peo3istr     "Continuing professional"
label variable peo4istr     "Recreational or avocational"
label variable peo5istr     "Adult basic or high school equivalency"
label variable peo6istr     "Secondary (high school)"
label variable peo7istr     "Developmental"
label variable cntlaffi     "Institutional control or affiliation"
label variable pubprime     "Primary public control"
label variable pubsecon     "Secondary public control"
label variable relaffil     "Religious affiliation"
label variable level1       "Certificate of less than 1 year"
label variable level1a      "Certificate of less than 12 weeks"
label variable level1b      "Certificate of at least 12 weeks, but less than 1 year"
label variable level2       "Certifiicate of at least 1 year, but less than 2 years"
label variable level3       "Associate's degree"
label variable level4       "Certificate of at least 2 years, but less than 4 years"
label variable level5       "Bachelor's degree"
label variable level6       "Postbaccalaureate certificate"
label variable level7       "Master's degree"
label variable level8       "Post-master's certificate"
label variable level12      "Other degree"
label variable level17      "Doctor's degree - research/scholarship"
label variable level18      "Doctor's degree - professional practice"
label variable level19      "Doctor's degree - other"
label variable calsys       "Calendar system"
label variable ft_ug        "Full-time undergraduate students are enrolled"
label variable ft_ftug      "Full time first-time degree/certificate-seeking undergraduate students enrolled"
label variable ftgdnidp     "Full-time graduate (not including doctor's professional practice) students are enrolled"
label variable pt_ug        "Part-time undergraduate students are enrolled"
label variable pt_ftug      "Part time first-time degree/certificate-seeking undergraduate students enrolled"
label variable ptgdnidp     "Part-time graduate (not including doctor's professional practice) students are enrolled"
label variable docpp        "Doctor's professional practice students are enrolled"
label variable docppsp      "Doctor's professional practice students are enrolled in programs formerly designated as first-professional"
label variable openadmp     "Open admission policy"
label variable noncrdt1     "Workforce Education"
label variable noncrdt2     "Contract Training/Customized Training"
label variable noncrdt3     "Developmental Education"
label variable noncrdt4     "Recreational/Avocational/Leisure/Personal Enrichment"
label variable noncrdt5     "Adult Basic Education"
label variable noncrdt6     "Adult High School Diploma or Equivalent"
label variable noncrdt7     "English as a Second Language"
label variable noncrdt8     "Continuing Professional Education"
label variable noncrdt9     "Institution does not offer noncredit education"
label variable enrhsst      "Enolls high school students in college courses for credit"
label variable enrhsst1     "Enolls high school students in college courses for credit within a dual enrollment program"
label variable enrhsst2     "Enolls high school students in college courses for credit outside a dual enrollment program"
label variable vet1         "Yellow Ribbon Program (officially known as Post-9/11 GI Bill, Yellow Ribbon Program)"
label variable vet2         "Credit for military training"
label variable vet3         "Dedicated point of contact for support services for veterans, military servicemembers, and their families"
label variable vet4         "Recognized student veteran organization"
label variable vet5         "Member of Department of Defense Voluntary Educational Partnership Memorandum of Understanding"
label variable vet9         "Services  and programs are not available to veterans, military servicemembers, or their families?"
label variable credits2     "Credit for life experiences"
label variable credits3     "Advanced placement (AP) credits"
label variable credits4     "Institution does not accept dual, credit for life, or AP credits"
label variable slo5         "ROTC"
label variable slo51        "ROTC - Army"
label variable slo52        "ROTC - Navy"
label variable slo521       "ROTC - Navy Marine Corps option"
label variable slo53        "ROTC - Air Force"
label variable slo6         "Study abroad"
label variable slo7         "Weekend/evening  college"
label variable slo8         "Teacher certification (below the postsecondary level)"
label variable slo81        "Teacher certification: Students can complete their preparation in certain areas of specialization"
label variable slo82        "Teacher certification: Students must complete their preparation at another institution for certain areas of specialization"
label variable slo83        "Teacher certification: Approved by the state for initial certifcation or licensure of teachers."
label variable slo9         "None of the above special learning opportunities are offered"
label variable sloa         "Undergraduate research (co-curricula)"
label variable slob         "Comprehensive transition and postsecondary program for students with intellectual disabilities"
label variable yrscoll      "Years of college-level work required"
label variable stusrv2      "Academic/career counseling service"
label variable stusrv3      "Employment services for students"
label variable stusrv4      "Placement services for completers"
label variable stusrv8      "On-campus day care for students' children"
label variable stusrv9      "None of the above selected services are offered"
label variable libres1      "Library resources/services: Physical facilities"
label variable libres2      "Library resources/services: Organized collection of printed materials"
label variable libres3      "Library resources/services: Access to digital/electronic resources"
label variable libres4      "Library resources/services: Staff trained to provide and interpret library materials"
label variable libres5      "Library resources/services: Established library hours"
label variable libres6      "Library resources/services: Access to library collections that are shared with other institutions"
label variable libres9      "Library resources/services not provided"
label variable tuitpl       "Any alternative tuition plans offered by institution"
label variable tuitpl1      "Tuition guaranteed plan"
label variable tuitpl2      "Prepaid tuition plan"
label variable tuitpl3      "Tuition payment plan"
label variable tuitpl4      "Other alternative tuition plan"
label variable prmpgm       "Participates in a Promise Program"
label variable dstnugc      "Undergraduate level distance education courses offered"
label variable dstnugp      "Undergraduate level distance education programs offered"
label variable dstnugn      "Undergraduate level distance education not offered"
label variable dstngc       "Graduate level distance education courses offered"
label variable dstngp       "Graduate level distance education programs offered"
label variable dstngn       "Graduate level distance education not offered"
label variable distcrs      "Distance education courses offered"
label variable distpgs      "Distance education programs offered"
label variable dstnced1     "Undergraduate level programs or courses are offered via distance education"
label variable dstnced2     "Graduate level programs or courses are offered via distance education"
label variable dstnced3     "Does not offer distance education opportunities"
label variable distnced     "All programs offered completely via distance education"
label variable disab        "Percent indicator of undergraduates formally registered as students with disabilities"
label variable xdisabpc     "Imputation field disabpct - Percent of undergraduates, who are formally registered as students with disabilities, when percentage is more than 3 percent"
label variable disabpct     "Percent of undergraduates, who are formally registered as students with disabilities, when percentage is more than 3 percent"
label variable alloncam     "Full-time, first-time degree/certificate-seeking students required to live on campus"
label variable tuitvary     "Tuition charge varies for in-district, in-state, out-of-state students"
label variable room         "Institution provide nstitutionally-controlled housing (on-campus and/or off-campus)"
label variable xroomcap     "Imputation field roomcap - Housing capacity"
label variable roomcap      "Housing capacity"
label variable board        "Institution offers food or meal plans"
label variable xmealswk     "Imputation field mealswk - Number of meals per week"
label variable mealswk      "Number of meals per week"
label variable xroomamt     "Imputation field roomamt - Typical housing charges for an academic year"
label variable roomamt      "Typical housing charges for an academic year"
label variable xbordamt     "Imputation field boardamt - Typical food charge for academic year"
label variable boardamt     "Typical food charge for academic year"
label variable xrmbdamt     "Imputation field rmbrdamt - Combined food and housing charge"
label variable rmbrdamt     "Combined food and housing charge"
label variable xappfeeu     "Imputation field applfeeu - Undergraduate application fee"
label variable applfeeu     "Undergraduate application fee"
label variable xappfeeg     "Imputation field applfeeg - Graduate application fee"
label variable applfeeg     "Graduate application fee"
label variable athassoc     "Member of National Athletic Association"
label variable assoc1       "Member of National Collegiate Athletic Association (NCAA)"
label variable assoc2       "Member of National Association of Intercollegiate Athletics (NAIA)"
label variable assoc3       "Member of National Junior College Athletic  Association (NJCAA)"
label variable assoc4       "Member of National Small College Athletic Association (NSCAA)"
label variable assoc5       "Member of National Christian College Athletic Association (NCCAA)"
label variable assoc6       "Member of other national athletic association not listed above"
label variable sport1       "NCAA/NAIA member for football"
label variable confno1      "NCAA/NAIA conference number football"
label variable sport2       "NCAA/NAIA member for basketball"
label variable confno2      "NCAA/NAIA conference number basketball"
label variable sport3       "NCAA/NAIA member for baseball"
label variable confno3      "NCAA/NAIA conference number baseball"
label variable sport4       "NCAA/NAIA member for cross country/track"
label variable confno4      "NCAA/NAIA conference number cross country/track"
label define label_peo1istr 1 "Yes"
label define label_peo1istr 0 "Implied no", add
label values peo1istr label_peo1istr
label define label_peo2istr 1 "Yes"
label define label_peo2istr 0 "Implied no", add
label values peo2istr label_peo2istr
label define label_peo3istr 1 "Yes"
label define label_peo3istr 0 "Implied no", add
label define label_peo3istr -2 "Not applicable", add
label values peo3istr label_peo3istr
label define label_peo4istr 1 "Yes"
label define label_peo4istr 0 "Implied no", add
label values peo4istr label_peo4istr
label define label_peo5istr 1 "Yes"
label define label_peo5istr 0 "Implied no", add
label values peo5istr label_peo5istr
label define label_peo6istr 1 "Yes"
label define label_peo6istr 0 "Implied no", add
label values peo6istr label_peo6istr
label define label_peo7istr 1 "Yes"
label define label_peo7istr 0 "Implied No", add
label values peo7istr label_peo7istr
label define label_cntlaffi 1 "Public"
label define label_cntlaffi 2 "Private for-profit", add
label define label_cntlaffi 3 "Private not-for-profit (no religious affiliation)", add
label define label_cntlaffi 4 "Private not-for-profit (religious affiliation)", add
label values cntlaffi label_cntlaffi
label define label_pubprime 1 "Federal"
label define label_pubprime 2 "State", add
label define label_pubprime 3 "Territorial", add
label define label_pubprime 4 "School district", add
label define label_pubprime 5 "County", add
label define label_pubprime 7 "City", add
label define label_pubprime 8 "Special district", add
label define label_pubprime 9 "Other", add
label define label_pubprime -2 "Not applicable", add
label values pubprime label_pubprime
label define label_pubsecon 1 "Federal"
label define label_pubsecon 2 "State", add
label define label_pubsecon 3 "Territorial", add
label define label_pubsecon 4 "School district", add
label define label_pubsecon 5 "County", add
label define label_pubsecon 6 "Township", add
label define label_pubsecon 7 "City", add
label define label_pubsecon 8 "Special district", add
label define label_pubsecon 9 "Other", add
label define label_pubsecon 0 "Implied no", add
label define label_pubsecon -2 "Not applicable", add
label values pubsecon label_pubsecon
label define label_relaffil 51 "African Methodist Episcopal"
label define label_relaffil 24 "African Methodist Episcopal Zion Church", add
label define label_relaffil 52 "American Baptist", add
label define label_relaffil 22 "American Evangelical Lutheran Church", add
label define label_relaffil 27 "Assemblies of God Church", add
label define label_relaffil 54 "Baptist", add
label define label_relaffil 28 "Brethren Church", add
label define label_relaffil 34 "Christ and Missionary Alliance Church", add
label define label_relaffil 61 "Christian Church (Disciples of Christ)", add
label define label_relaffil 48 "Christian Churches and Churches of Christ", add
label define label_relaffil 55 "Christian Methodist Episcopal", add
label define label_relaffil 35 "Christian Reformed Church", add
label define label_relaffil 58 "Church of Brethren", add
label define label_relaffil 57 "Church of God", add
label define label_relaffil 59 "Church of the Nazarene", add
label define label_relaffil 74 "Churches of Christ", add
label define label_relaffil 60 "Cumberland Presbyterian", add
label define label_relaffil 50 "Episcopal Church, Reformed", add
label define label_relaffil 102 "Evangelical Christian", add
label define label_relaffil 37 "Evangelical Covenant Church of America", add
label define label_relaffil 38 "Evangelical Free Church of America", add
label define label_relaffil 39 "Evangelical Lutheran Church", add
label define label_relaffil 64 "Free Methodist", add
label define label_relaffil 41 "Free Will Baptist Church", add
label define label_relaffil 65 "Friends", add
label define label_relaffil 105 "General Baptist", add
label define label_relaffil 91 "Greek Orthodox", add
label define label_relaffil 42 "Interdenominational", add
label define label_relaffil 80 "Jewish", add
label define label_relaffil 68 "Lutheran Church - Missouri Synod", add
label define label_relaffil 67 "Lutheran Church in America", add
label define label_relaffil 43 "Mennonite Brethren Church", add
label define label_relaffil 69 "Mennonite Church", add
label define label_relaffil 87 "Missionary Church Inc", add
label define label_relaffil 44 "Moravian Church", add
label define label_relaffil 78 "Multiple Protestant Denomination", add
label define label_relaffil 108 "Non-Denominational", add
label define label_relaffil 45 "North American Baptist", add
label define label_relaffil 100 "Original Free Will Baptist", add
label define label_relaffil 110 "Orthodox Christian", add
label define label_relaffil 79 "Other Protestant", add
label define label_relaffil 47 "Pentecostal Holiness Church", add
label define label_relaffil 107 "Plymouth Brethren", add
label define label_relaffil 103 "Presbyterian", add
label define label_relaffil 66 "Presbyterian Church (USA)", add
label define label_relaffil 73 "Protestant Episcopal", add
label define label_relaffil 49 "Reformed Church in America", add
label define label_relaffil 81 "Reformed Presbyterian Church", add
label define label_relaffil 30 "Roman Catholic", add
label define label_relaffil 92 "Russian Orthodox", add
label define label_relaffil 95 "Seventh Day Adventist", add
label define label_relaffil 75 "Southern Baptist", add
label define label_relaffil 94 "The Church of Jesus Christ of Latter-day Saints", add
label define label_relaffil 97 "The Presbyterian Church in America", add
label define label_relaffil 88 "Undenominational", add
label define label_relaffil 93 "Unitarian Universalist", add
label define label_relaffil 84 "United Brethren Church", add
label define label_relaffil 76 "United Church of Christ", add
label define label_relaffil 71 "United Methodist", add
label define label_relaffil 89 "Wesleyan", add
label define label_relaffil 33 "Wisconsin Evangelical Lutheran Synod", add
label define label_relaffil 99 "Other (none of the above)", add
label define label_relaffil -2 "Not applicable", add
label values relaffil label_relaffil
label define label_level1 1 "Yes"
label define label_level1 0 "Implied no", add
label values level1 label_level1
label define label_level1a 1 "Yes"
label define label_level1a 0 "Implied no", add
label values level1a label_level1a
label define label_level1b 1 "Yes"
label define label_level1b 0 "implied no", add
label values level1b label_level1b
label define label_level2 1 "Yes"
label define label_level2 0 "Implied no", add
label values level2 label_level2
label define label_level3 1 "Yes"
label define label_level3 0 "Implied no", add
label values level3 label_level3
label define label_level4 1 "Yes"
label define label_level4 0 "Implied no", add
label values level4 label_level4
label define label_level5 1 "Yes"
label define label_level5 0 "Implied no", add
label define label_level5 -2 "Not applicable", add
label values level5 label_level5
label define label_level6 1 "Yes"
label define label_level6 0 "Implied no", add
label define label_level6 -2 "Not applicable", add
label values level6 label_level6
label define label_level7 1 "Yes"
label define label_level7 0 "Implied no", add
label define label_level7 -2 "Not applicable", add
label values level7 label_level7
label define label_level8 1 "Yes"
label define label_level8 0 "Implied no", add
label define label_level8 -2 "Not applicable", add
label values level8 label_level8
label define label_level17 1 "Yes"
label define label_level17 0 "Implied no", add
label define label_level17 -2 "Not applicable", add
label values level17 label_level17
label define label_level18 1 "Yes"
label define label_level18 0 "Implied no", add
label define label_level18 -2 "Not applicable", add
label values level18 label_level18
label define label_level19 1 "Yes"
label define label_level19 0 "Implied no", add
label define label_level19 -2 "Not applicable", add
label values level19 label_level19
label define label_level12 0 "Implied no"
label values level12 label_level12
label define label_openadmp 1 "Yes"
label define label_openadmp 2 "No", add
label define label_openadmp -2 "Not applicable", add
label values openadmp label_openadmp
label define label_credits2 1 "Yes"
label define label_credits2 0 "Implied no", add
label define label_credits2 -1 "Not reported", add
label define label_credits2 -2 "Not applicable", add
label values credits2 label_credits2
label define label_credits3 1 "Yes"
label define label_credits3 0 "Implied no", add
label define label_credits3 -1 "Not reported", add
label define label_credits3 -2 "Not applicable", add
label values credits3 label_credits3
label define label_credits4 1 "Yes"
label define label_credits4 0 "Implied no", add
label define label_credits4 -1 "Not reported", add
label define label_credits4 -2 "Not applicable", add
label values credits4 label_credits4
label define label_slo5 1 "Yes"
label define label_slo5 0 "Implied no", add
label define label_slo5 -1 "Not reported", add
label define label_slo5 -2 "Not applicable", add
label values slo5 label_slo5
label define label_slo51 1 "Yes"
label define label_slo51 0 "Implied no", add
label define label_slo51 -1 "Not reported", add
label define label_slo51 -2 "Not applicable", add
label values slo51 label_slo51
label define label_slo52 1 "Yes"
label define label_slo52 0 "Implied no", add
label define label_slo52 -1 "Not reported", add
label define label_slo52 -2 "Not applicable", add
label values slo52 label_slo52
label define label_slo521 1 "Yes"
label define label_slo521 0 "Implied No", add
label define label_slo521 -1 "Not reported", add
label define label_slo521 -2 "Not applicable", add
label values slo521 label_slo521
label define label_slo53 1 "Yes"
label define label_slo53 0 "Implied no", add
label define label_slo53 -1 "Not reported", add
label define label_slo53 -2 "Not applicable", add
label values slo53 label_slo53
label define label_slo6 1 "Yes"
label define label_slo6 0 "Implied no", add
label define label_slo6 -1 "Not reported", add
label define label_slo6 -2 "Not applicable", add
label values slo6 label_slo6
label define label_slo7 1 "Yes"
label define label_slo7 0 "Implied no", add
label define label_slo7 -1 "Not reported", add
label define label_slo7 -2 "Not applicable", add
label values slo7 label_slo7
label define label_sloa 1 "Yes"
label define label_sloa 0 "Implied No", add
label define label_sloa -1 "Not reported", add
label define label_sloa -2 "Not applicable", add
label values sloa label_sloa
label define label_slo8 1 "Yes"
label define label_slo8 0 "Implied no", add
label define label_slo8 -1 "Not reported", add
label define label_slo8 -2 "Not applicable", add
label values slo8 label_slo8
label define label_slo81 1 "Yes"
label define label_slo81 0 "Implied no", add
label define label_slo81 -1 "Not reported", add
label define label_slo81 -2 "Not applicable", add
label values slo81 label_slo81
label define label_slo82 1 "Yes"
label define label_slo82 0 "Implied no", add
label define label_slo82 -1 "Not reported", add
label define label_slo82 -2 "Not applicable", add
label values slo82 label_slo82
label define label_slo83 1 "Yes"
label define label_slo83 0 "Implied no", add
label define label_slo83 -1 "Not reported", add
label define label_slo83 -2 "Not applicable", add
label values slo83 label_slo83
label define label_slob 1 "Yes"
label define label_slob 0 "Implied No", add
label define label_slob -1 "Not reported", add
label define label_slob -2 "Not applicable", add
label values slob label_slob
label define label_slo9 1 "Yes"
label define label_slo9 0 "Implied no", add
label define label_slo9 -1 "Not reported", add
label define label_slo9 -2 "Not applicable", add
label values slo9 label_slo9
label define label_yrscoll 1 "One"
label define label_yrscoll 2 "Two", add
label define label_yrscoll 3 "Three", add
label define label_yrscoll 4 "Four", add
label define label_yrscoll 5 "Five", add
label define label_yrscoll 6 "Six", add
label define label_yrscoll 8 "Eight", add
label define label_yrscoll -1 "Not reported", add
label define label_yrscoll -2 "Not applicable", add
label values yrscoll label_yrscoll
label define label_stusrv2 1 "Yes"
label define label_stusrv2 0 "Implied no", add
label define label_stusrv2 -1 "Not reported", add
label define label_stusrv2 -2 "Not applicable", add
label values stusrv2 label_stusrv2
label define label_stusrv3 1 "Yes"
label define label_stusrv3 0 "Implied no", add
label define label_stusrv3 -1 "Not reported", add
label define label_stusrv3 -2 "Not applicable", add
label values stusrv3 label_stusrv3
label define label_stusrv4 1 "Yes"
label define label_stusrv4 0 "Implied no", add
label define label_stusrv4 -1 "Not reported", add
label define label_stusrv4 -2 "Not applicable", add
label values stusrv4 label_stusrv4
label define label_stusrv8 1 "Yes"
label define label_stusrv8 0 "Implied no", add
label define label_stusrv8 -1 "Not reported", add
label define label_stusrv8 -2 "Not applicable", add
label values stusrv8 label_stusrv8
label define label_stusrv9 1 "Yes"
label define label_stusrv9 0 "Implied no", add
label define label_stusrv9 -1 "Not reported", add
label define label_stusrv9 -2 "Not applicable", add
label values stusrv9 label_stusrv9
label define label_athassoc 1 "Yes"
label define label_athassoc 2 "No", add
label define label_athassoc -1 "Not reported", add
label define label_athassoc -2 "Not applicable", add
label values athassoc label_athassoc
label define label_assoc1 1 "Yes"
label define label_assoc1 0 "Implied no", add
label define label_assoc1 -1 "Not reported", add
label define label_assoc1 -2 "Not applicable", add
label values assoc1 label_assoc1
label define label_assoc2 1 "Yes"
label define label_assoc2 0 "Implied no", add
label define label_assoc2 -1 "Not reported", add
label define label_assoc2 -2 "Not applicable", add
label values assoc2 label_assoc2
label define label_assoc3 1 "Yes"
label define label_assoc3 0 "Implied no", add
label define label_assoc3 -1 "Not reported", add
label define label_assoc3 -2 "Not applicable", add
label values assoc3 label_assoc3
label define label_assoc4 1 "Yes"
label define label_assoc4 0 "Implied no", add
label define label_assoc4 -1 "Not reported", add
label define label_assoc4 -2 "Not applicable", add
label values assoc4 label_assoc4
label define label_assoc5 1 "Yes"
label define label_assoc5 0 "Implied no", add
label define label_assoc5 -1 "Not reported", add
label define label_assoc5 -2 "Not applicable", add
label values assoc5 label_assoc5
label define label_assoc6 1 "Yes"
label define label_assoc6 0 "Implied no", add
label define label_assoc6 -1 "Not reported", add
label define label_assoc6 -2 "Not applicable", add
label values assoc6 label_assoc6
label define label_sport1 1 "Yes"
label define label_sport1 2 "No", add
label define label_sport1 -1 "Not reported", add
label define label_sport1 -2 "Not applicable", add
label values sport1 label_sport1
label define label_confno1 372 "American Athletic Conference"
label define label_confno1 176 "American Rivers Conference", add
label define label_confno1 204 "American Southwest Conference", add
label define label_confno1 316 "Appalachian Athletic Conference", add
label define label_confno1 102 "Atlantic Coast Conference", add
label define label_confno1 135 "Atlantic Sun Conference", add
label define label_confno1 105 "Big Sky Conference", add
label define label_confno1 106 "Big South Conference", add
label define label_confno1 107 "Big Ten Conference", add
label define label_confno1 108 "Big Twelve Conference", add
label define label_confno1 301 "California Pacific Conference", add
label define label_confno1 165 "Centennial Conference", add
label define label_confno1 140 "Central Intercollegiate Athletic Association", add
label define label_confno1 304 "Chicagoland Collegiate Athletic Conference", add
label define label_confno1 167 "College Conference of Illinois and Wisconsin", add
label define label_confno1 378 "Collegiate Conference of the South", add
label define label_confno1 110 "Colonial Athletic Association", add
label define label_confno1 168 "Commonwealth Coast Conference", add
label define label_confno1 139 "Conference Carolinas", add
label define label_confno1 111 "Conference USA", add
label define label_confno1 377 "Continental Athletic Conference", add
label define label_confno1 112 "Division I Independents", add
label define label_confno1 113 "Division I-A Independents", add
label define label_confno1 141 "Division II Independents", add
label define label_confno1 170 "Division III Independents", add
label define label_confno1 151 "East Coast Conference", add
label define label_confno1 366 "Eastern Collegiate Football Conference", add
label define label_confno1 172 "Empire Eight", add
label define label_confno1 333 "The Sun Conference", add
label define label_confno1 173 "Freedom Football Conference", add
label define label_confno1 352 "Frontier Conference", add
label define label_confno1 302 "Golden State Athletic Conference", add
label define label_confno1 367 "Great American Conference", add
label define label_confno1 144 "Great Lakes Intercollegiate Athletic Conference", add
label define label_confno1 371 "Great Midwest Athletic Conference", add
label define label_confno1 145 "Great Lakes Valley Conference", add
label define label_confno1 213 "Great Northwest Athletic Conference", add
label define label_confno1 311 "Great Plains Athletic Conference", add
label define label_confno1 146 "Gulf South Conference", add
label define label_confno1 320 "Heart of America Athletic Conference", add
label define label_confno1 175 "Heartland Collegiate Athletic Conference", add
label define label_confno1 327 "Independent Northeast Region", add
label define label_confno1 335 "Independent Southeast Region", add
label define label_confno1 117 "Ivy Group", add
label define label_confno1 309 "Kansas Collegiate Athletic Conference", add
label define label_confno1 361 "Landmark Conference", add
label define label_confno1 147 "Lone Star Conference", add
label define label_confno1 179 "Massachusetts State College Athletic Association", add
label define label_confno1 180 "Michigan Intercollegiate Athletic Association", add
label define label_confno1 148 "Mid-America Intercollegiate Athletic Association", add
label define label_confno1 119 "Mid-American Conference", add
label define label_confno1 121 "Mid-Eastern Athletic Conference", add
label define label_confno1 315 "Mid-South Conference", add
label define label_confno1 356 "Mid-States Football Association", add
label define label_confno1 181 "Middle Atlantic States Athletic Corporation", add
label define label_confno1 182 "Midwest Conference", add
label define label_confno1 183 "Minnesota Intercollegiate Athletic Conference", add
label define label_confno1 123 "Missouri Valley Conference", add
label define label_confno1 370 "Mountain East Conference", add
label define label_confno1 203 "Mountain West Conference", add
label define label_confno1 184 "New England Football Conference", add
label define label_confno1 185 "New England Small College Athletic Conference", add
label define label_confno1 186 "New England Women^s & Men^s Athletic Conference", add
label define label_confno1 187 "New Jersey Athletic Conference", add
label define label_confno1 189 "North Coast Athletic Conference", add
label define label_confno1 373 "North Star Athletic Association", add
label define label_confno1 153 "Northeast 10 Conference", add
label define label_confno1 125 "Northeast Conference", add
label define label_confno1 359 "Northern Athletics Collegiate Conference", add
label define label_confno1 155 "Northern Sun Intercollegiate Conference", add
label define label_confno1 205 "Northwest Conference", add
label define label_confno1 191 "Ohio Athletic Conference", add
label define label_confno1 126 "Ohio Valley Conference", add
label define label_confno1 192 "Old Dominion Athletic Conference", add
label define label_confno1 127 "Pacific-12 Conference", add
label define label_confno1 128 "Patriot League", add
label define label_confno1 158 "Pennsylvania State Athletic Conference", add
label define label_confno1 129 "Pioneer Football League", add
label define label_confno1 194 "Presidents^ Athletic Conference", add
label define label_confno1 159 "Rocky Mountain Athletic Conference", add
label define label_confno1 340 "Sooner Athletic Conference", add
label define label_confno1 160 "South Atlantic Conference", add
label define label_confno1 130 "Southeastern Conference", add
label define label_confno1 368 "Southern Athletic Association", add
label define label_confno1 197 "Southern California Intercollegiate Athletic Conference", add
label define label_confno1 131 "Southern Conference", add
label define label_confno1 161 "Southern Intercollegiate Athletic Conference", add
label define label_confno1 132 "Southland Conference", add
label define label_confno1 133 "Southwestern Athletic Conference", add
label define label_confno1 134 "Sun Belt Conference", add
label define label_confno1 379 "United Athletic Conference", add
label define label_confno1 171 "USA South Athletic Conference", add
label define label_confno1 200 "University Athletic Association", add
label define label_confno1 354 "Upper Midwest Athletic Conference", add
label define label_confno1 201 "Upstate Collegiate Athletic Association", add
label define label_confno1 137 "Western Athletic Conference", add
label define label_confno1 202 "Wisconsin Intercollegiate Athletic Conference", add
label define label_confno1 342 "Other", add
label define label_confno1 -1 "Not reported", add
label define label_confno1 -2 "Not applicable", add
label values confno1 label_confno1
label define label_sport2 1 "Yes"
label define label_sport2 2 "No", add
label define label_sport2 -1 "Not reported", add
label define label_sport2 -2 "Not applicable", add
label values sport2 label_sport2
label define label_confno2 214 "Allegheny Mountain Collegiate Conference"
label define label_confno2 101 "America East", add
label define label_confno2 372 "American Athletic Conference", add
label define label_confno2 319 "American Midwest Conference", add
label define label_confno2 176 "American Rivers Conference", add
label define label_confno2 204 "American Southwest Conference", add
label define label_confno2 316 "Appalachian Athletic Conference", add
label define label_confno2 103 "Atlantic 10 Conference", add
label define label_confno2 102 "Atlantic Coast Conference", add
label define label_confno2 375 "Atlantic East Conference", add
label define label_confno2 135 "Atlantic Sun Conference", add
label define label_confno2 104 "Big East Conference", add
label define label_confno2 105 "Big Sky Conference", add
label define label_confno2 106 "Big South Conference", add
label define label_confno2 107 "Big Ten Conference", add
label define label_confno2 108 "Big Twelve Conference", add
label define label_confno2 109 "Big West Conference", add
label define label_confno2 138 "California Collegiate Athletic Association", add
label define label_confno2 301 "California Pacific Conference", add
label define label_confno2 164 "Capital Athletic Conference", add
label define label_confno2 328 "Cascade Collegiate Conference", add
label define label_confno2 165 "Centennial Conference", add
label define label_confno2 323 "Central Atlantic Collegiate Conference", add
label define label_confno2 140 "Central Intercollegiate Athletic Association", add
label define label_confno2 304 "Chicagoland Collegiate Athletic Conference", add
label define label_confno2 166 "City University of New York Athletic Conference", add
label define label_confno2 167 "College Conference of Illinois and Wisconsin", add
label define label_confno2 378 "Collegiate Conference of the South", add
label define label_confno2 110 "Colonial Athletic Association", add
label define label_confno2 364 "Colonial States Athletic Conference", add
label define label_confno2 168 "Commonwealth Coast Conference", add
label define label_confno2 207 "Commonwealth Conference", add
label define label_confno2 139 "Conference Carolinas", add
label define label_confno2 111 "Conference USA", add
label define label_confno2 377 "Continental Athletic Conference", add
label define label_confno2 305 "Crossroads League", add
label define label_confno2 112 "Division I Independents", add
label define label_confno2 141 "Division II Independents", add
label define label_confno2 170 "Division III Independents", add
label define label_confno2 151 "East Coast Conference", add
label define label_confno2 115 "Eastern College Athletic Conference", add
label define label_confno2 172 "Empire Eight", add
label define label_confno2 333 "The Sun Conference", add
label define label_confno2 208 "Freedom Conference", add
label define label_confno2 352 "Frontier Conference", add
label define label_confno2 302 "Golden State Athletic Conference", add
label define label_confno2 367 "Great American Conference", add
label define label_confno2 144 "Great Lakes Intercollegiate Athletic Conference", add
label define label_confno2 371 "Great Midwest Athletic Conference", add
label define label_confno2 145 "Great Lakes Valley Conference", add
label define label_confno2 174 "Great Northeast Athletic Conference", add
label define label_confno2 213 "Great Northwest Athletic Conference", add
label define label_confno2 311 "Great Plains Athletic Conference", add
label define label_confno2 337 "Gulf Coast Athletic Conference", add
label define label_confno2 146 "Gulf South Conference", add
label define label_confno2 320 "Heart of America Athletic Conference", add
label define label_confno2 175 "Heartland Collegiate Athletic Conference", add
label define label_confno2 209 "Heartland Conference", add
label define label_confno2 122 "Horizon League", add
label define label_confno2 318 "Independent Mid-South Region", add
label define label_confno2 322 "Independent Midwest Region", add
label define label_confno2 327 "Independent Northeast Region", add
label define label_confno2 335 "Independent Southeast Region", add
label define label_confno2 117 "Ivy Group", add
label define label_confno2 309 "Kansas Collegiate Athletic Conference", add
label define label_confno2 361 "Landmark Conference", add
label define label_confno2 178 "Little East Conference", add
label define label_confno2 147 "Lone Star Conference", add
label define label_confno2 179 "Massachusetts State College Athletic Association", add
label define label_confno2 118 "Metro Atlantic Athletic Conference", add
label define label_confno2 180 "Michigan Intercollegiate Athletic Association", add
label define label_confno2 148 "Mid-America Intercollegiate Athletic Association", add
label define label_confno2 119 "Mid-American Conference", add
label define label_confno2 121 "Mid-Eastern Athletic Conference", add
label define label_confno2 315 "Mid-South Conference", add
label define label_confno2 181 "Middle Atlantic States Athletic Corporation", add
label define label_confno2 182 "Midwest Conference", add
label define label_confno2 183 "Minnesota Intercollegiate Athletic Conference", add
label define label_confno2 123 "Missouri Valley Conference", add
label define label_confno2 370 "Mountain East Conference", add
label define label_confno2 203 "Mountain West Conference", add
label define label_confno2 185 "New England Small College Athletic Conference", add
label define label_confno2 186 "New England Women^s & Men^s Athletic Conference", add
label define label_confno2 187 "New Jersey Athletic Conference", add
label define label_confno2 215 "North Atlantic Conference", add
label define label_confno2 189 "North Coast Athletic Conference", add
label define label_confno2 365 "United East Conference", add
label define label_confno2 373 "North Star Athletic Association", add
label define label_confno2 153 "Northeast 10 Conference", add
label define label_confno2 125 "Northeast Conference", add
label define label_confno2 359 "Northern Athletics Collegiate Conference", add
label define label_confno2 155 "Northern Sun Intercollegiate Conference", add
label define label_confno2 205 "Northwest Conference", add
label define label_confno2 191 "Ohio Athletic Conference", add
label define label_confno2 126 "Ohio Valley Conference", add
label define label_confno2 192 "Old Dominion Athletic Conference", add
label define label_confno2 156 "Pacific West Conference", add
label define label_confno2 127 "Pacific-12 Conference", add
label define label_confno2 128 "Patriot League", add
label define label_confno2 157 "Peach Belt Conference", add
label define label_confno2 158 "Pennsylvania State Athletic Conference", add
label define label_confno2 194 "Presidents^ Athletic Conference", add
label define label_confno2 353 "Red River Athletic Conference", add
label define label_confno2 374 "River States", add
label define label_confno2 159 "Rocky Mountain Athletic Conference", add
label define label_confno2 196 "Skyline Conference", add
label define label_confno2 340 "Sooner Athletic Conference", add
label define label_confno2 160 "South Atlantic Conference", add
label define label_confno2 130 "Southeastern Conference", add
label define label_confno2 368 "Southern Athletic Association", add
label define label_confno2 197 "Southern California Intercollegiate Athletic Conference", add
label define label_confno2 198 "Southern Collegiate Athletic Conference", add
label define label_confno2 131 "Southern Conference", add
label define label_confno2 161 "Southern Intercollegiate Athletic Conference", add
label define label_confno2 334 "Southern States Athletic Conference", add
label define label_confno2 132 "Southland Conference", add
label define label_confno2 133 "Southwestern Athletic Conference", add
label define label_confno2 195 "St. Louis Intercollegiate Athletic Conference", add
label define label_confno2 199 "State University of New York Athletic Conference", add
label define label_confno2 134 "Sun Belt Conference", add
label define label_confno2 162 "Sunshine State Conference", add
label define label_confno2 120 "The Summit League", add
label define label_confno2 171 "USA South Athletic Conference", add
label define label_confno2 200 "University Athletic Association", add
label define label_confno2 354 "Upper Midwest Athletic Conference", add
label define label_confno2 201 "Upstate Collegiate Athletic Association", add
label define label_confno2 136 "West Coast Conference", add
label define label_confno2 137 "Western Athletic Conference", add
label define label_confno2 202 "Wisconsin Intercollegiate Ath Conference", add
label define label_confno2 307 "Wolverine-Hoosier Athletic Conference", add
label define label_confno2 342 "Other", add
label define label_confno2 -1 "Not reported", add
label define label_confno2 -2 "Not applicable", add
label values confno2 label_confno2
label define label_sport3 1 "Yes"
label define label_sport3 2 "No", add
label define label_sport3 -1 "Not reported", add
label define label_sport3 -2 "Not applicable", add
label values sport3 label_sport3
label define label_confno3 214 "Allegheny Mountain Collegiate Conference"
label define label_confno3 101 "America East", add
label define label_confno3 372 "American Athletic Conference", add
label define label_confno3 319 "American Midwest Conference", add
label define label_confno3 176 "American Rivers Conference", add
label define label_confno3 204 "American Southwest Conference", add
label define label_confno3 316 "Appalachian Athletic Conference", add
label define label_confno3 369 "Association of Independent Institutions", add
label define label_confno3 103 "Atlantic 10 Conference", add
label define label_confno3 102 "Atlantic Coast Conference", add
label define label_confno3 375 "Atlantic East Conference", add
label define label_confno3 135 "Atlantic Sun Conference", add
label define label_confno3 104 "Big East Conference", add
label define label_confno3 105 "Big Sky Conference", add
label define label_confno3 106 "Big South Conference", add
label define label_confno3 107 "Big Ten Conference", add
label define label_confno3 108 "Big Twelve Conference", add
label define label_confno3 109 "Big West Conference", add
label define label_confno3 138 "California Collegiate Athletic Association", add
label define label_confno3 301 "California Pacific Conference", add
label define label_confno3 164 "Capital Athletic Conference", add
label define label_confno3 328 "Cascade Collegiate Conference", add
label define label_confno3 165 "Centennial Conference", add
label define label_confno3 323 "Central Atlantic Collegiate Conference", add
label define label_confno3 140 "Central Intercollegiate Athletic Association", add
label define label_confno3 304 "Chicagoland Collegiate Athletic Conference", add
label define label_confno3 166 "City University of New York Athletic Conference", add
label define label_confno3 167 "College Conference of Illinois and Wisconsin", add
label define label_confno3 378 "Collegiate Conference of the South", add
label define label_confno3 110 "Colonial Athletic Association", add
label define label_confno3 364 "Colonial States Athletic Conference", add
label define label_confno3 168 "Commonwealth Coast Conference", add
label define label_confno3 207 "Commonwealth Conference", add
label define label_confno3 139 "Conference Carolinas", add
label define label_confno3 111 "Conference USA", add
label define label_confno3 377 "Continental Athletic Conference", add
label define label_confno3 305 "Crossroads League", add
label define label_confno3 141 "Division II Independents", add
label define label_confno3 170 "Division III Independents", add
label define label_confno3 151 "East Coast Conference", add
label define label_confno3 115 "Eastern College Athletic Conference", add
label define label_confno3 172 "Empire Eight", add
label define label_confno3 333 "The Sun Conference", add
label define label_confno3 208 "Freedom Conference", add
label define label_confno3 302 "Golden State Athletic Conference", add
label define label_confno3 367 "Great American Conference", add
label define label_confno3 144 "Great Lakes Intercollegiate Athletic Conference", add
label define label_confno3 371 "Great Midwest Athletic Conference", add
label define label_confno3 145 "Great Lakes Valley Conference", add
label define label_confno3 174 "Great Northeast Athletic Conference", add
label define label_confno3 213 "Great Northwest Athletic Conference", add
label define label_confno3 311 "Great Plains Athletic Conference", add
label define label_confno3 337 "Gulf Coast Athletic Conference", add
label define label_confno3 146 "Gulf South Conference", add
label define label_confno3 320 "Heart of America Athletic Conference", add
label define label_confno3 175 "Heartland Collegiate Athletic Conference", add
label define label_confno3 209 "Heartland Conference", add
label define label_confno3 122 "Horizon League", add
label define label_confno3 318 "Independent Mid-South Region", add
label define label_confno3 322 "Independent Midwest Region", add
label define label_confno3 335 "Independent Southeast Region", add
label define label_confno3 117 "Ivy Group", add
label define label_confno3 309 "Kansas Collegiate Athletic Conference", add
label define label_confno3 361 "Landmark Conference", add
label define label_confno3 178 "Little East Conference", add
label define label_confno3 147 "Lone Star Conference", add
label define label_confno3 179 "Massachusetts State College Athletic Association", add
label define label_confno3 118 "Metro Atlantic Athletic Conference", add
label define label_confno3 180 "Michigan Intercollegiate Athletic Association", add
label define label_confno3 148 "Mid-America Intercollegiate Athletic Association", add
label define label_confno3 119 "Mid-American Conference", add
label define label_confno3 121 "Mid-Eastern Athletic Conference", add
label define label_confno3 315 "Mid-South Conference", add
label define label_confno3 181 "Middle Atlantic States Athletic Corporation", add
label define label_confno3 182 "Midwest Conference", add
label define label_confno3 183 "Minnesota Intercollegiate Athletic Conference", add
label define label_confno3 123 "Missouri Valley Conference", add
label define label_confno3 370 "Mountain East Conference", add
label define label_confno3 203 "Mountain West Conference", add
label define label_confno3 185 "New England Small College Athletic Conference", add
label define label_confno3 186 "New England Women^s & Men^s Athletic Conference", add
label define label_confno3 187 "New Jersey Athletic Conference", add
label define label_confno3 215 "North Atlantic Conference", add
label define label_confno3 189 "North Coast Athletic Conference", add
label define label_confno3 365 "United East Conference", add
label define label_confno3 373 "North Star Athletic Association", add
label define label_confno3 153 "Northeast 10 Conference", add
label define label_confno3 125 "Northeast Conference", add
label define label_confno3 359 "Northern Athletics Collegiate Conference", add
label define label_confno3 155 "Northern Sun Intercollegiate Conference", add
label define label_confno3 205 "Northwest Conference", add
label define label_confno3 191 "Ohio Athletic Conference", add
label define label_confno3 126 "Ohio Valley Conference", add
label define label_confno3 192 "Old Dominion Athletic Conference", add
label define label_confno3 156 "Pacific West Conference", add
label define label_confno3 127 "Pacific-12 Conference", add
label define label_confno3 128 "Patriot League", add
label define label_confno3 157 "Peach Belt Conference", add
label define label_confno3 158 "Pennsylvania State Athletic Conference", add
label define label_confno3 194 "Presidents^ Athletic Conference", add
label define label_confno3 353 "Red River Athletic Conference", add
label define label_confno3 374 "River States", add
label define label_confno3 159 "Rocky Mountain Athletic Conference", add
label define label_confno3 196 "Skyline Conference", add
label define label_confno3 340 "Sooner Athletic Conference", add
label define label_confno3 160 "South Atlantic Conference", add
label define label_confno3 130 "Southeastern Conference", add
label define label_confno3 368 "Southern Athletic Association", add
label define label_confno3 197 "Southern California Intercollegiate Athletic Conference", add
label define label_confno3 198 "Southern Collegiate Athletic Conference", add
label define label_confno3 131 "Southern Conference", add
label define label_confno3 161 "Southern Intercollegiate Athletic Conference", add
label define label_confno3 334 "Southern States Athletic Conference", add
label define label_confno3 132 "Southland Conference", add
label define label_confno3 133 "Southwestern Athletic Conference", add
label define label_confno3 195 "St. Louis Intercollegiate Athletic Conference", add
label define label_confno3 199 "State University of New York Athletic Conference", add
label define label_confno3 134 "Sun Belt Conference", add
label define label_confno3 162 "Sunshine State Conference", add
label define label_confno3 120 "The Summit League", add
label define label_confno3 171 "USA South Athletic Conference", add
label define label_confno3 200 "University Athletic Association", add
label define label_confno3 354 "Upper Midwest Athletic Conference", add
label define label_confno3 201 "Upstate Collegiate Athletic Association", add
label define label_confno3 136 "West Coast Conference", add
label define label_confno3 137 "Western Athletic Conference", add
label define label_confno3 202 "Wisconsin Intercollegiate Athletic Conference", add
label define label_confno3 307 "Wolverine-Hoosier Athletic Conference", add
label define label_confno3 342 "Other", add
label define label_confno3 -1 "Not reported", add
label define label_confno3 -2 "Not applicable", add
label values confno3 label_confno3
label define label_sport4 1 "Yes"
label define label_sport4 2 "No", add
label define label_sport4 -1 "Not reported", add
label define label_sport4 -2 "Not applicable", add
label values sport4 label_sport4
label define label_confno4 214 "Allegheny Mountain Collegiate Conference"
label define label_confno4 101 "America East", add
label define label_confno4 372 "American Athletic Conference", add
label define label_confno4 319 "American Midwest Conference", add
label define label_confno4 176 "American Rivers Conference", add
label define label_confno4 204 "American Southwest Conference", add
label define label_confno4 316 "Appalachian Athletic Conference", add
label define label_confno4 103 "Atlantic 10 Conference", add
label define label_confno4 102 "Atlantic Coast Conference", add
label define label_confno4 375 "Atlantic East Conference", add
label define label_confno4 135 "Atlantic Sun Conference", add
label define label_confno4 104 "Big East Conference", add
label define label_confno4 105 "Big Sky Conference", add
label define label_confno4 106 "Big South Conference", add
label define label_confno4 107 "Big Ten Conference", add
label define label_confno4 108 "Big Twelve Conference", add
label define label_confno4 109 "Big West Conference", add
label define label_confno4 138 "California Collegiate Athletic Association", add
label define label_confno4 301 "California Pacific Conference", add
label define label_confno4 164 "Capital Athletic Conference", add
label define label_confno4 328 "Cascade Collegiate Conference", add
label define label_confno4 165 "Centennial Conference", add
label define label_confno4 323 "Central Atlantic Collegiate Conference", add
label define label_confno4 140 "Central Intercollegiate Athletic Association", add
label define label_confno4 304 "Chicagoland Collegiate Athletic Conference", add
label define label_confno4 166 "City University of New York Athletic Conference", add
label define label_confno4 167 "College Conference of Illinois and Wisconsin", add
label define label_confno4 378 "Collegiate Conference of the South", add
label define label_confno4 110 "Colonial Athletic Association", add
label define label_confno4 364 "Colonial States Athletic Conference", add
label define label_confno4 168 "Commonwealth Coast Conference", add
label define label_confno4 139 "Conference Carolinas", add
label define label_confno4 111 "Conference USA", add
label define label_confno4 377 "Continental Athletic Conference", add
label define label_confno4 305 "Crossroads League", add
label define label_confno4 112 "Division I Independents", add
label define label_confno4 141 "Division II Independents", add
label define label_confno4 170 "Division III Independents", add
label define label_confno4 151 "East Coast Conference", add
label define label_confno4 115 "Eastern College Athletic Conference", add
label define label_confno4 172 "Empire Eight", add
label define label_confno4 333 "The Sun Conference", add
label define label_confno4 208 "Freedom Conference", add
label define label_confno4 352 "Frontier Conference", add
label define label_confno4 302 "Golden State Athletic Conference", add
label define label_confno4 367 "Great American Conference", add
label define label_confno4 144 "Great Lakes Intercollegiate Athletic Conference", add
label define label_confno4 145 "Great Lakes Valley Conference", add
label define label_confno4 371 "Great Midwest Athletic Conference", add
label define label_confno4 174 "Great Northeast Athletic Conference", add
label define label_confno4 213 "Great Northwest Athletic Conference", add
label define label_confno4 311 "Great Plains Athletic Conference", add
label define label_confno4 337 "Gulf Coast Athletic Conference", add
label define label_confno4 146 "Gulf South Conference", add
label define label_confno4 320 "Heart of America Athletic Conference", add
label define label_confno4 175 "Heartland Collegiate Athletic Conference", add
label define label_confno4 122 "Horizon League", add
label define label_confno4 318 "Independent Mid-South Region", add
label define label_confno4 322 "Independent Midwest Region", add
label define label_confno4 335 "Independent Southeast Region", add
label define label_confno4 117 "Ivy Group", add
label define label_confno4 309 "Kansas Collegiate Athletic Conference", add
label define label_confno4 361 "Landmark Conference", add
label define label_confno4 178 "Little East Conference", add
label define label_confno4 147 "Lone Star Conference", add
label define label_confno4 179 "Massachusetts State College Athletic Association", add
label define label_confno4 118 "Metro Atlantic Athletic Conference", add
label define label_confno4 180 "Michigan Intercollegiate Athletic Association", add
label define label_confno4 148 "Mid-America Intercollegiate Athletic Association", add
label define label_confno4 119 "Mid-American Conference", add
label define label_confno4 121 "Mid-Eastern Athletic Conference", add
label define label_confno4 315 "Mid-South Conference", add
label define label_confno4 181 "Middle Atlantic States Athletic Corporation", add
label define label_confno4 182 "Midwest Conference", add
label define label_confno4 183 "Minnesota Intercollegiate Athletic Conference", add
label define label_confno4 123 "Missouri Valley Conference", add
label define label_confno4 370 "Mountain East Conference", add
label define label_confno4 203 "Mountain West Conference", add
label define label_confno4 185 "New England Small College Athletic Conference", add
label define label_confno4 186 "New England Women^s & Men^s Athletic Conference", add
label define label_confno4 187 "New Jersey Athletic Conference", add
label define label_confno4 215 "North Atlantic Conference", add
label define label_confno4 189 "North Coast Athletic Conference", add
label define label_confno4 365 "United East Conference", add
label define label_confno4 373 "North Star Athletic Association", add
label define label_confno4 153 "Northeast 10 Conference", add
label define label_confno4 125 "Northeast Conference", add
label define label_confno4 359 "Northern Athletics Conference", add
label define label_confno4 155 "Northern Sun Intercollegiate Conference", add
label define label_confno4 205 "Northwest Conference", add
label define label_confno4 191 "Ohio Athletic Conference", add
label define label_confno4 126 "Ohio Valley Conference", add
label define label_confno4 192 "Old Dominion Athletic Conference", add
label define label_confno4 156 "Pacific West Conference", add
label define label_confno4 127 "Pacific-12 Conference", add
label define label_confno4 128 "Patriot League", add
label define label_confno4 157 "Peach Belt Conference", add
label define label_confno4 158 "Pennsylvania State Athletic Conference", add
label define label_confno4 194 "Presidents^ Athletic Conference", add
label define label_confno4 353 "Red River Athletic Conference", add
label define label_confno4 374 "River States", add
label define label_confno4 159 "Rocky Mountain Athletic Conference", add
label define label_confno4 196 "Skyline Conference", add
label define label_confno4 340 "Sooner Athletic Conference", add
label define label_confno4 160 "South Atlantic Conference", add
label define label_confno4 130 "Southeastern Conference", add
label define label_confno4 368 "Southern Athletic Association", add
label define label_confno4 197 "Southern California Intercollegiate Athletic Conference", add
label define label_confno4 198 "Southern Collegiate Athletic Conference", add
label define label_confno4 131 "Southern Conference", add
label define label_confno4 161 "Southern Intercollegiate Athletic Conference", add
label define label_confno4 334 "Southern States Athletic Conference", add
label define label_confno4 132 "Southland Conference", add
label define label_confno4 133 "Southwestern Athletic Conference", add
label define label_confno4 195 "St. Louis Intercollegiate Athletic Conference", add
label define label_confno4 199 "State University of New York Athletic Conference", add
label define label_confno4 134 "Sun Belt Conference", add
label define label_confno4 162 "Sunshine State Conference", add
label define label_confno4 120 "The Summit League", add
label define label_confno4 171 "USA South Athletic Conference", add
label define label_confno4 200 "University Athletic Association", add
label define label_confno4 354 "Upper Midwest Athletic Conference", add
label define label_confno4 201 "Upstate Collegiate Athletic Association", add
label define label_confno4 136 "West Coast Conference", add
label define label_confno4 137 "Western Athletic Conference", add
label define label_confno4 202 "Wisconsin Intercollegiate Athletic Conference", add
label define label_confno4 307 "Wolverine-Hoosier Athletic Conference", add
label define label_confno4 342 "Other", add
label define label_confno4 -1 "Not reported", add
label define label_confno4 -2 "Not applicable", add
label values confno4 label_confno4
label define label_calsys 1 "Semester"
label define label_calsys 2 "Quarter", add
label define label_calsys 3 "Trimester", add
label define label_calsys 4 "Four-one-four plan", add
label define label_calsys 5 "Other academic year", add
label define label_calsys 6 "Differs by program", add
label define label_calsys 7 "Continuous", add
label define label_calsys -2 "Not applicable", add
label values calsys label_calsys
label define label_ft_ug 1 "Yes"
label define label_ft_ug 2 "No", add
label define label_ft_ug -2 "Not applicable", add
label values ft_ug label_ft_ug
label define label_ft_ftug 1 "Yes"
label define label_ft_ftug 2 "No", add
label define label_ft_ftug -2 "Not applicable", add
label values ft_ftug label_ft_ftug
label define label_pt_ug 1 "Yes"
label define label_pt_ug 2 "No", add
label define label_pt_ug -2 "Not applicable", add
label values pt_ug label_pt_ug
label define label_pt_ftug 1 "Yes"
label define label_pt_ftug 2 "No", add
label define label_pt_ftug -2 "Not applicable", add
label values pt_ftug label_pt_ftug
label define label_tuitvary 1 "Yes"
label define label_tuitvary 2 "No", add
label define label_tuitvary -1 "Not reported", add
label define label_tuitvary -2 "Not applicable", add
label values tuitvary label_tuitvary
label define label_room 1 "Yes"
label define label_room 2 "No", add
label define label_room -1 "Not reported", add
label define label_room -2 "Not applicable", add
label values room label_room
label define label_board 1 "Yes, number of meals in the maximum meal plan offered"
label define label_board 2 "Yes, number of meals per week can vary", add
label define label_board 3 "No", add
label define label_board -1 "Not reported", add
label define label_board -2 "Not applicable", add
label values board label_board
label define label_alloncam 1 "Yes"
label define label_alloncam 2 "No", add
label define label_alloncam -1 "Not reported", add
label define label_alloncam -2 "Not applicable", add
label values alloncam label_alloncam
label define label_tuitpl 1 "Yes"
label define label_tuitpl 2 "No", add
label define label_tuitpl -1 "Not reported", add
label define label_tuitpl -2 "Not applicable", add
label values tuitpl label_tuitpl
label define label_tuitpl1 1 "Yes"
label define label_tuitpl1 0 "Implied no", add
label define label_tuitpl1 -1 "Not reported", add
label define label_tuitpl1 -2 "Not applicable", add
label values tuitpl1 label_tuitpl1
label define label_tuitpl2 1 "Yes"
label define label_tuitpl2 0 "Implied no", add
label define label_tuitpl2 -1 "Not reported", add
label define label_tuitpl2 -2 "Not applicable", add
label values tuitpl2 label_tuitpl2
label define label_tuitpl3 1 "Yes"
label define label_tuitpl3 0 "Implied no", add
label define label_tuitpl3 -1 "Not reported", add
label define label_tuitpl3 -2 "Not applicable", add
label values tuitpl3 label_tuitpl3
label define label_tuitpl4 1 "Yes"
label define label_tuitpl4 0 "Implied no", add
label define label_tuitpl4 -1 "Not reported", add
label define label_tuitpl4 -2 "Not applicable", add
label values tuitpl4 label_tuitpl4
label define label_ftgdnidp 1 "Yes"
label define label_ftgdnidp 2 "No", add
label define label_ftgdnidp -2 "Not applicable", add
label values ftgdnidp label_ftgdnidp
label define label_ptgdnidp 1 "Yes"
label define label_ptgdnidp 2 "No", add
label define label_ptgdnidp -2 "Not applicable", add
label values ptgdnidp label_ptgdnidp
label define label_docpp 1 "Yes"
label define label_docpp 2 "No", add
label define label_docpp -2 "Not applicable", add
label values docpp label_docpp
label define label_docppsp 1 "Yes"
label define label_docppsp 2 "No", add
label define label_docppsp -2 "Not applicable", add
label values docppsp label_docppsp
label define label_distcrs 1 "Yes"
label define label_distcrs 0 "Implied no", add
label define label_distcrs -1 "Not reported", add
label define label_distcrs -2 "Not applicable", add
label values distcrs label_distcrs
label define label_distnced 1 "Yes"
label define label_distnced 2 "No", add
label define label_distnced -1 "Not reported", add
label define label_distnced -2 "Not applicable", add
label values distnced label_distnced
label define label_dstnced1 1 "Yes"
label define label_dstnced1 0 "Implied no", add
label define label_dstnced1 -1 "Not reported", add
label define label_dstnced1 -2 "Not applicable", add
label values dstnced1 label_dstnced1
label define label_dstnced2 1 "Yes"
label define label_dstnced2 0 "Implied no", add
label define label_dstnced2 -1 "Not reported", add
label define label_dstnced2 -2 "Not applicable", add
label values dstnced2 label_dstnced2
label define label_dstnced3 1 "Yes"
label define label_dstnced3 0 "Implied no", add
label define label_dstnced3 -1 "Not reported", add
label define label_dstnced3 -2 "Not applicable", add
label values dstnced3 label_dstnced3
label define label_dstnugc 1 "Yes"
label define label_dstnugc 0 "Implied no", add
label define label_dstnugc -1 "Not reported", add
label define label_dstnugc -2 "Not applicable", add
label values dstnugc label_dstnugc
label define label_dstnugp 1 "Yes"
label define label_dstnugp 0 "Implied no", add
label define label_dstnugp -1 "Not reported", add
label define label_dstnugp -2 "Not applicable", add
label values dstnugp label_dstnugp
label define label_dstnugn 1 "Yes"
label define label_dstnugn 0 "Implied no", add
label define label_dstnugn -1 "Not reported", add
label define label_dstnugn -2 "Not applicable", add
label values dstnugn label_dstnugn
label define label_dstngc 1 "Yes"
label define label_dstngc 0 "Implied no", add
label define label_dstngc -1 "Not reported", add
label define label_dstngc -2 "Not applicable", add
label values dstngc label_dstngc
label define label_dstngp 1 "Yes"
label define label_dstngp 0 "Implied no", add
label define label_dstngp -1 "Not reported", add
label define label_dstngp -2 "Not applicable", add
label values dstngp label_dstngp
label define label_dstngn 1 "Yes"
label define label_dstngn 0 "Implied no", add
label define label_dstngn -1 "Not reported", add
label define label_dstngn -2 "Not applicable", add
label values dstngn label_dstngn
label values distpgs label_distpgs
label define label_vet1 1 "Yes"
label define label_vet1 0 "Implied no", add
label define label_vet1 -1 "Not reported", add
label define label_vet1 -2 "Not applicable", add
label values vet1 label_vet1
label define label_vet2 1 "Yes"
label define label_vet2 0 "Implied no", add
label define label_vet2 -1 "Not reported", add
label define label_vet2 -2 "Not applicable", add
label values vet2 label_vet2
label define label_vet3 1 "Yes"
label define label_vet3 0 "Implied no", add
label define label_vet3 -1 "Not reported", add
label define label_vet3 -2 "Not applicable", add
label values vet3 label_vet3
label define label_vet4 1 "Yes"
label define label_vet4 0 "Implied no", add
label define label_vet4 -1 "Not reported", add
label define label_vet4 -2 "Not applicable", add
label values vet4 label_vet4
label define label_vet5 1 "Yes"
label define label_vet5 0 "Implied no", add
label define label_vet5 -1 "Not reported", add
label define label_vet5 -2 "Not applicable", add
label values vet5 label_vet5
label define label_vet9 1 "Yes"
label define label_vet9 0 "Implied no", add
label define label_vet9 -1 "Not reported", add
label define label_vet9 -2 "Not applicable", add
label values vet9 label_vet9
label define label_libres1 1 "Yes"
label define label_libres1 0 "Implied no", add
label define label_libres1 -1 "Not reported", add
label define label_libres1 -2 "Not applicable", add
label values libres1 label_libres1
label define label_libres2 1 "Yes"
label define label_libres2 0 "Implied no", add
label define label_libres2 -1 "Not reported", add
label define label_libres2 -2 "Not applicable", add
label values libres2 label_libres2
label define label_libres3 1 "Yes"
label define label_libres3 0 "Implied no", add
label define label_libres3 -1 "Not reported", add
label define label_libres3 -2 "Not applicable", add
label values libres3 label_libres3
label define label_libres4 1 "Yes"
label define label_libres4 0 "Implied no", add
label define label_libres4 -1 "Not reported", add
label define label_libres4 -2 "Not applicable", add
label values libres4 label_libres4
label define label_libres5 1 "Yes"
label define label_libres5 0 "Implied no", add
label define label_libres5 -1 "Not reported", add
label define label_libres5 -2 "Not applicable", add
label values libres5 label_libres5
label define label_libres6 1 "Yes"
label define label_libres6 0 "Implied no", add
label define label_libres6 -1 "Not reported", add
label define label_libres6 -2 "Not applicable", add
label values libres6 label_libres6
label define label_libres9 1 "Yes"
label define label_libres9 0 "Implied no", add
label define label_libres9 -1 "Not reported", add
label define label_libres9 -2 "Not applicable", add
label values libres9 label_libres9
label define label_noncrdt1 1 "Yes"
label define label_noncrdt1 0 "Implied No", add
label define label_noncrdt1 -2 "Not applicable", add
label values noncrdt1 label_noncrdt1
label define label_noncrdt2 1 "Yes"
label define label_noncrdt2 0 "Implied No", add
label define label_noncrdt2 -2 "Not applicable", add
label values noncrdt2 label_noncrdt2
label define label_noncrdt3 1 "Yes"
label define label_noncrdt3 0 "Implied No", add
label define label_noncrdt3 -2 "Not applicable", add
label values noncrdt3 label_noncrdt3
label define label_noncrdt4 1 "Yes"
label define label_noncrdt4 0 "Implied No", add
label define label_noncrdt4 -2 "Not applicable", add
label values noncrdt4 label_noncrdt4
label define label_noncrdt5 1 "Yes"
label define label_noncrdt5 0 "Implied No", add
label define label_noncrdt5 -2 "Not applicable", add
label values noncrdt5 label_noncrdt5
label define label_noncrdt6 1 "Yes"
label define label_noncrdt6 0 "Implied No", add
label define label_noncrdt6 -2 "Not applicable", add
label values noncrdt6 label_noncrdt6
label define label_noncrdt7 1 "Yes"
label define label_noncrdt7 0 "Implied No", add
label define label_noncrdt7 -2 "Not applicable", add
label values noncrdt7 label_noncrdt7
label define label_noncrdt8 1 "Yes"
label define label_noncrdt8 0 "Implied No", add
label define label_noncrdt8 -2 "Not applicable", add
label values noncrdt8 label_noncrdt8
label define label_noncrdt9 1 "Yes"
label define label_noncrdt9 0 "Implied No", add
label define label_noncrdt9 -2 "Not applicable", add
label values noncrdt9 label_noncrdt9
label define label_prmpgm 1 "Yes"
label define label_prmpgm 2 "No", add
label define label_prmpgm -1 "Not reported", add
label define label_prmpgm -2 "Not applicable", add
label values prmpgm label_prmpgm
label define label_enrhsst 1 "Yes"
label define label_enrhsst 2 "No", add
label define label_enrhsst -2 "Not applicable", add
label values enrhsst label_enrhsst
label define label_enrhsst1 1 "Yes"
label define label_enrhsst1 0 "Implied no", add
label define label_enrhsst1 -2 "Not applicable", add
label values enrhsst1 label_enrhsst1
label define label_enrhsst2 1 "Yes"
label define label_enrhsst2 0 "Implied no", add
label define label_enrhsst2 -2 "Not applicable", add
label values enrhsst2 label_enrhsst2
label define label_disab 1 "3 percent or less"
label define label_disab 2 "More than 3 percent", add
label define label_disab -1 "Not reported", add
label define label_disab -2 "Not applicable", add
label values disab label_disab
*The following are the possible values for the item imputation field variables
*A Not applicable
*B Institution left item blank
*C Analyst corrected reported value
*D Do not know
*G Data generated from other data values
*H Value not derived - data not usable
*J Logical imputation
*K Ratio adjustment
*L Imputed using the Group Median procedure
*N Imputed using Nearest Neighbor procedure
*P Imputed using Carry Forward procedure
*R Reported
*Y Specific professional practice program n
*Z Implied zero;
tab peo1istr
tab peo2istr
tab peo3istr
tab peo4istr
tab peo5istr
tab peo6istr
tab peo7istr
tab cntlaffi
tab pubprime
tab pubsecon
tab relaffil
tab level1
tab level1a
tab level1b
tab level2
tab level3
tab level4
tab level5
tab level6
tab level7
tab level8
tab level17
tab level18
tab level19
tab level12
tab openadmp
tab credits2
tab credits3
tab credits4
tab slo5
tab slo51
tab slo52
tab slo521
tab slo53
tab slo6
tab slo7
tab sloa
tab slo8
tab slo81
tab slo82
tab slo83
tab slob
tab slo9
tab yrscoll
tab stusrv2
tab stusrv3
tab stusrv4
tab stusrv8
tab stusrv9
tab athassoc
tab assoc1
tab assoc2
tab assoc3
tab assoc4
tab assoc5
tab assoc6
tab sport1
tab confno1
tab sport2
tab confno2
tab sport3
tab confno3
tab sport4
tab confno4
tab calsys
tab ft_ug
tab ft_ftug
tab pt_ug
tab pt_ftug
tab tuitvary
tab room
tab board
tab alloncam
tab tuitpl
tab tuitpl1
tab tuitpl2
tab tuitpl3
tab tuitpl4
tab ftgdnidp
tab ptgdnidp
tab docpp
tab docppsp
tab distcrs
tab distnced
tab dstnced1
tab dstnced2
tab dstnced3
tab dstnugc
tab dstnugp
tab dstnugn
tab dstngc
tab dstngp
tab dstngn
tab distpgs
tab vet1
tab vet2
tab vet3
tab vet4
tab vet5
tab vet9
tab libres1
tab libres2
tab libres3
tab libres4
tab libres5
tab libres6
tab libres9
tab noncrdt1
tab noncrdt2
tab noncrdt3
tab noncrdt4
tab noncrdt5
tab noncrdt6
tab noncrdt7
tab noncrdt8
tab noncrdt9
tab prmpgm
tab enrhsst
tab enrhsst1
tab enrhsst2
tab disab
tab xappfeeu
tab xappfeeg
tab xroomcap
tab xmealswk
tab xroomamt
tab xbordamt
tab xrmbdamt
tab xdisabpc
summarize applfeeu
summarize applfeeg
summarize roomcap
summarize mealswk
summarize roomamt
summarize boardamt
summarize rmbrdamt
summarize disabpct
save dct_ic2023
